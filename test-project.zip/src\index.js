const express = require("express");\nconst app = express();\napp.get("/api/users", async (req, res) => {\n  const users = await db.findAll();\n  res.json(users);\n});\napp.listen(3000);

function validate(input) {\n  return input && input.length > 0;\n}\nmodule.exports = { validate };
